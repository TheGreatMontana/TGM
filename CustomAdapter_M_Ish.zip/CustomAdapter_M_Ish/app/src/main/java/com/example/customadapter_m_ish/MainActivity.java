package com.example.customadapter_m_ish;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity{
    private ListView lvProduct;
    private ProductListAdapter adapter;
    private List<Product> mProductList;
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lvProduct = (ListView)findViewById(R.id.listview_product);

        mProductList = new ArrayList<>();


        mProductList.add(new Product(1, "Iphone 15", 899, "Apple Iphone 15 128GB"));
        mProductList.add(new Product(2, "Iphone 15 Plus+", 999, "Apple Iphone 15 Plus 128GB"));
        mProductList.add(new Product(3, "Iphone 15 Pro", 1099, "Apple Iphone 15 Pro 128GB"));
        mProductList.add(new Product(4, "Iphone 15 Pro Max", 1199, "Apple Iphone 15 Pro Max 256GB"));


        adapter = new ProductListAdapter(getApplicationContext(), mProductList);
        lvProduct.setAdapter(adapter);

        lvProduct.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(getApplicationContext(), "Clicked product id = " + view.getTag(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
